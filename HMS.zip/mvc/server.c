/*
 * ============================================================
 *  Digital Diary — HTTP Server in C
 *  Compile : cl /Fe:server.exe server.c ws2_32.lib     (Windows)
 *            gcc server.c -o server                    (Linux/Mac)
 *  Run     : ./server
 *  Browse  : http://localhost:8080
 * ============================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#include <direct.h>
#pragma comment(lib, "ws2_32.lib")
typedef SOCKET socket_t;
#define CLOSE_SOCKET closesocket
#define MKDIR(path) _mkdir(path)
#else
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/stat.h>
typedef int socket_t;
#define INVALID_SOCKET (-1)
#define SOCKET_ERROR (-1)
#define CLOSE_SOCKET close
#define MKDIR(path) mkdir(path, 0755)
#endif

/* ── Configuration ──────────────────────────────────────── */
#define PORT          8080
#define BACKLOG       10
#define BUF_SIZE      8192
#define MAX_ENTRIES   1000
#define DATA_FILE     "data/diary.txt"
#define ENTRY_SEP     "---ENTRY---\n"

/* ── Entry structure ────────────────────────────────────── */
typedef struct {
    char id[32];
    char date[32];
    char title[256];
    char content[4096];
} DiaryEntry;

/* ══════════════════════════════════════════════════════════
   UTILITY HELPERS
   ══════════════════════════════════════════════════════════ */

/* URL-decode a percent-encoded string in-place */
void url_decode(char *dst, const char *src, size_t max) {
    size_t i = 0, j = 0;
    while (src[i] && j < max - 1) {
        if (src[i] == '%' && src[i+1] && src[i+2]) {
            char hex[3] = { src[i+1], src[i+2], '\0' };
            dst[j++] = (char)strtol(hex, NULL, 16);
            i += 3;
        } else if (src[i] == '+') {
            dst[j++] = ' ';
            i++;
        } else {
            dst[j++] = src[i++];
        }
    }
    dst[j] = '\0';
}

/* Extract a single field value from "key=value&..." form data */
int get_field(const char *body, const char *key, char *out, size_t out_max) {
    char search[64];
    snprintf(search, sizeof(search), "%s=", key);
    const char *p = strstr(body, search);
    if (!p) { out[0] = '\0'; return 0; }
    p += strlen(search);
    const char *end = strchr(p, '&');
    size_t len = end ? (size_t)(end - p) : strlen(p);
    if (len >= out_max) len = out_max - 1;
    char *raw = malloc(len + 1);
    if (!raw) { out[0] = '\0'; return 0; }
    strncpy(raw, p, len);
    raw[len] = '\0';
    url_decode(out, raw, out_max);
    free(raw);
    return 1;
}

/* HTML-escape a string to prevent XSS */
void html_escape(char *dst, const char *src, size_t max) {
    size_t i = 0, j = 0;
    while (src[i] && j + 8 < max) {
        switch (src[i]) {
            case '&':  strcpy(dst+j, "&amp;");  j+=5; break;
            case '<':  strcpy(dst+j, "&lt;");   j+=4; break;
            case '>':  strcpy(dst+j, "&gt;");   j+=4; break;
            case '"':  strcpy(dst+j, "&quot;"); j+=6; break;
            case '\'': strcpy(dst+j, "&#39;");  j+=5; break;
            default:   dst[j++] = src[i]; break;
        }
        i++;
    }
    dst[j] = '\0';
}

/* Generate a simple timestamp-based ID */
void gen_id(char *out) {
    time_t now = time(NULL);
    snprintf(out, 32, "%ld%03ld", (long)now, (long)(clock() % 1000));
}

/* ══════════════════════════════════════════════════════════
   FILE STORAGE  (diary.txt — newline-separated records)
   Format per entry:
     ---ENTRY---
     ID:<id>
     DATE:<date>
     TITLE:<title>
     CONTENT:<content (newlines replaced by \n literal)>
   ══════════════════════════════════════════════════════════ */

/* Encode newlines inside content as literal \n for single-line storage */
void encode_newlines(char *dst, const char *src, size_t max) {
    size_t i = 0, j = 0;
    while (src[i] && j + 3 < max) {
        if (src[i] == '\n') { dst[j++]='\\'; dst[j++]='n'; }
        else if (src[i] == '\r') { i++; continue; }
        else { dst[j++] = src[i]; }
        i++;
    }
    dst[j] = '\0';
}

/* Decode literal \n back to real newlines */
void decode_newlines(char *dst, const char *src, size_t max) {
    size_t i = 0, j = 0;
    while (src[i] && j + 2 < max) {
        if (src[i] == '\\' && src[i+1] == 'n') { dst[j++]='\n'; i+=2; }
        else { dst[j++] = src[i++]; }
    }
    dst[j] = '\0';
}

/* Append one entry to the data file */
int save_entry(const DiaryEntry *e) {
    /* Ensure data/ directory exists */
    MKDIR("data");

    FILE *f = fopen(DATA_FILE, "a");
    if (!f) return 0;

    char enc_content[sizeof(e->content) * 2];
    encode_newlines(enc_content, e->content, sizeof(enc_content));

    fprintf(f, "%sID:%s\nDATE:%s\nTITLE:%s\nCONTENT:%s\n",
            ENTRY_SEP, e->id, e->date, e->title, enc_content);
    fclose(f);
    return 1;
}

/* Load all entries from file; returns count */
int load_entries(DiaryEntry *entries, int max_count) {
    FILE *f = fopen(DATA_FILE, "r");
    if (!f) return 0;

    int count = 0;
    char line[8192];
    DiaryEntry *cur = NULL;

    while (fgets(line, sizeof(line), f) && count < max_count) {
        /* Strip trailing newline */
        size_t l = strlen(line);
        if (l > 0 && line[l-1] == '\n') line[l-1] = '\0';

        if (strcmp(line, "---ENTRY---") == 0) {
            cur = &entries[count++];
            memset(cur, 0, sizeof(DiaryEntry));
        } else if (cur) {
            if      (strncmp(line, "ID:",      3) == 0) { strncpy(cur->id,    line+3, 31);  cur->id[31] = '\0'; }
            else if (strncmp(line, "DATE:",    5) == 0) { strncpy(cur->date,  line+5, 31);  cur->date[31] = '\0'; }
            else if (strncmp(line, "TITLE:",   6) == 0) { strncpy(cur->title, line+6, 255); cur->title[255] = '\0'; }
            else if (strncmp(line, "CONTENT:", 8) == 0) {
                char decoded[sizeof(cur->content)];
                decode_newlines(decoded, line+8, sizeof(decoded));
                strncpy(cur->content, decoded, sizeof(cur->content)-1);
                cur->content[sizeof(cur->content)-1] = '\0';
            }
        }
    }
    fclose(f);
    return count;
}

/* Delete entry by ID — rewrite the whole file without that entry */
int delete_entry(const char *id) {
    DiaryEntry *entries = calloc(MAX_ENTRIES, sizeof(DiaryEntry));
    if (!entries) return 0;
    int count = load_entries(entries, MAX_ENTRIES);
    if (count == 0) {
        free(entries);
        return 0;
    }

    FILE *f = fopen(DATA_FILE, "w");
    if (!f) {
        free(entries);
        return 0;
    }

    int deleted = 0;
    for (int i = 0; i < count; i++) {
        if (strcmp(entries[i].id, id) == 0) { deleted = 1; continue; }
        char enc[sizeof(entries[i].content) * 2];
        encode_newlines(enc, entries[i].content, sizeof(enc));
        fprintf(f, "%sID:%s\nDATE:%s\nTITLE:%s\nCONTENT:%s\n",
                ENTRY_SEP, entries[i].id, entries[i].date,
                entries[i].title, enc);
    }
    fclose(f);
    free(entries);
    return deleted;
}

/* ══════════════════════════════════════════════════════════
   HTML TEMPLATE ENGINE
   The HTML pages are embedded as C strings so the binary
   is completely self-contained — no templates/ folder needed,
   though you can serve static files too.
   ══════════════════════════════════════════════════════════ */

/* ── Shared page wrapper ──────────────────────────────────
   Returns a heap-allocated string — caller must free().    */
char *wrap_page(const char *title, const char *body) {
    /* Inline CSS for the diary's warm, notebook-like aesthetic */
    static const char *css =
        "<style>"
        ":root{"
        "--ink:#1a1008;"
        "--paper:#fdf6e3;"
        "--paper2:#f7edcf;"
        "--accent:#c0392b;"
        "--accent2:#e67e22;"
        "--line:#d4c4a0;"
        "--shadow:rgba(0,0,0,.15);"
        "}"
        "*{box-sizing:border-box;margin:0;padding:0}"
        "body{font-family:'Georgia',serif;background:var(--paper);"
        "color:var(--ink);min-height:100vh;"
        "background-image:repeating-linear-gradient(transparent,transparent 27px,var(--line) 27px,var(--line) 28px);"
        "background-size:100% 28px;}"
        "a{color:var(--accent);text-decoration:none}"
        "a:hover{text-decoration:underline}"
        /* Nav */
        "nav{background:var(--ink);padding:0 2rem;"
        "display:flex;align-items:center;gap:2rem;"
        "box-shadow:0 2px 8px var(--shadow);position:sticky;top:0;z-index:100}"
        "nav .brand{color:#fff;font-size:1.5rem;font-weight:bold;"
        "letter-spacing:.05em;padding:1rem 0;flex:1}"
        "nav .brand span{color:var(--accent2)}"
        "nav a{color:#ccc;font-size:.95rem;padding:1rem .5rem;"
        "border-bottom:3px solid transparent;transition:.2s}"
        "nav a:hover{color:#fff;text-decoration:none;border-color:var(--accent2)}"
        /* Main container */
        ".container{max-width:820px;margin:0 auto;padding:2.5rem 2rem}"
        "h1{font-size:2rem;margin-bottom:1.5rem;color:var(--accent);"
        "border-bottom:2px solid var(--line);padding-bottom:.5rem}"
        "h2{font-size:1.3rem;margin-bottom:.75rem;color:var(--ink)}"
        /* Cards */
        ".card{background:rgba(255,255,255,.55);border:1px solid var(--line);"
        "border-radius:4px;padding:1.5rem;margin-bottom:1.5rem;"
        "box-shadow:2px 2px 8px var(--shadow);position:relative}"
        ".card-date{font-size:.8rem;color:#888;margin-bottom:.3rem}"
        ".card-title{font-size:1.25rem;font-weight:bold;margin-bottom:.6rem}"
        ".card-content{line-height:1.7;white-space:pre-wrap;font-size:.95rem}"
        ".card-actions{margin-top:1rem;display:flex;gap:.75rem}"
        /* Forms */
        "form{background:rgba(255,255,255,.55);border:1px solid var(--line);"
        "border-radius:4px;padding:2rem;box-shadow:2px 2px 8px var(--shadow)}"
        ".field{margin-bottom:1.2rem}"
        "label{display:block;font-size:.85rem;font-weight:bold;"
        "margin-bottom:.3rem;color:#555;text-transform:uppercase;letter-spacing:.05em}"
        "input[type=text],input[type=date],textarea{"
        "width:100%;padding:.65rem .9rem;border:1px solid var(--line);"
        "border-radius:3px;background:rgba(255,255,255,.8);"
        "font-family:inherit;font-size:1rem;color:var(--ink);"
        "transition:border-color .2s,box-shadow .2s}"
        "input:focus,textarea:focus{outline:none;"
        "border-color:var(--accent);box-shadow:0 0 0 3px rgba(192,57,43,.15)}"
        "textarea{min-height:180px;resize:vertical;line-height:1.7}"
        /* Buttons */
        ".btn{display:inline-block;padding:.6rem 1.4rem;"
        "border-radius:3px;border:none;cursor:pointer;"
        "font-family:inherit;font-size:.95rem;font-weight:bold;"
        "transition:all .2s;text-align:center}"
        ".btn-primary{background:var(--accent);color:#fff}"
        ".btn-primary:hover{background:#a93226;text-decoration:none}"
        ".btn-secondary{background:var(--ink);color:#fff}"
        ".btn-secondary:hover{background:#333;text-decoration:none}"
        ".btn-danger{background:#fff;color:var(--accent);"
        "border:1px solid var(--accent)}"
        ".btn-danger:hover{background:var(--accent);color:#fff;text-decoration:none}"
        ".btn-sm{padding:.35rem .9rem;font-size:.85rem}"
        /* Alerts */
        ".alert{padding:1rem 1.5rem;border-radius:4px;margin-bottom:1.5rem;font-size:.95rem}"
        ".alert-success{background:#d4edda;border:1px solid #c3e6cb;color:#155724}"
        ".alert-error{background:#f8d7da;border:1px solid #f5c6cb;color:#721c24}"
        ".alert-info{background:#d1ecf1;border:1px solid #bee5eb;color:#0c5460}"
        /* Hero on home */
        ".hero{text-align:center;padding:3rem 0 2rem}"
        ".hero h1{font-size:2.8rem;border:none;margin-bottom:.5rem}"
        ".hero p{color:#666;font-size:1.1rem;margin-bottom:2rem}"
        ".hero-actions{display:flex;gap:1rem;justify-content:center;flex-wrap:wrap}"
        /* Search */
        ".search-bar{display:flex;gap:.75rem;margin-bottom:2rem}"
        ".search-bar input{flex:1}"
        /* Empty state */
        ".empty{text-align:center;padding:3rem;color:#999;font-size:1.1rem}"
        ".tag{display:inline-block;background:var(--accent2);color:#fff;"
        "border-radius:20px;padding:.15rem .7rem;font-size:.75rem;margin-left:.5rem}"
        "</style>";

    static const char *nav =
        "<nav>"
        "<span class='brand'>&#128221; <span>My</span>Diary</span>"
        "<a href='/'>Home</a>"
        "<a href='/add'>New Entry</a>"
        "<a href='/view'>All Entries</a>"
        "<a href='/search'>Search</a>"
        "</nav>";

    size_t total = strlen(css) + strlen(nav) + strlen(title) + strlen(body) + 512;
    char *page = malloc(total);
    if (!page) return NULL;

    snprintf(page, total,
        "<!DOCTYPE html><html lang='en'>"
        "<head><meta charset='UTF-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<title>%s — MyDiary</title>%s</head>"
        "<body>%s<div class='container'>%s</div></body></html>",
        title, css, nav, body);
    return page;
}

/* ── Individual page builders ────────────────────────────── */

char *page_home(void) {
    DiaryEntry *entries = calloc(MAX_ENTRIES, sizeof(DiaryEntry));
    if (!entries) return wrap_page("Home", "<p>Error loading entries.</p>");
    int count = load_entries(entries, MAX_ENTRIES);
    free(entries);

    char stats[128];
    snprintf(stats, sizeof(stats),
        "You have <strong>%d</strong> entr%s in your diary.",
        count, count == 1 ? "y" : "ies");

    char body[2048];
    snprintf(body, sizeof(body),
        "<div class='hero'>"
        "<h1>&#128221; MyDiary</h1>"
        "<p>A private space for your thoughts, memories, and moments.</p>"
        "<p><em>%s</em></p>"
        "<div class='hero-actions'>"
        "<a href='/add' class='btn btn-primary'>&#43; New Entry</a>"
        "<a href='/view' class='btn btn-secondary'>&#128196; View All</a>"
        "<a href='/search' class='btn btn-secondary'>&#128269; Search</a>"
        "</div></div>",
        stats);
    return wrap_page("Home", body);
}

char *page_add(const char *msg, int is_error) {
    char alert[512] = "";
    if (msg && *msg) {
        snprintf(alert, sizeof(alert),
            "<div class='alert %s'>%s</div>",
            is_error ? "alert-error" : "alert-success", msg);
    }

    /* Default today's date */
    char today[16];
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    strftime(today, sizeof(today), "%Y-%m-%d", tm);

    char body[2048];
    snprintf(body, sizeof(body),
        "<h1>&#9997; New Entry</h1>%s"
        "<form method='POST' action='/save'>"
        "<div class='field'>"
        "<label>Date</label>"
        "<input type='date' name='date' value='%s' required>"
        "</div>"
        "<div class='field'>"
        "<label>Title</label>"
        "<input type='text' name='title' placeholder='What happened today?' required maxlength='200'>"
        "</div>"
        "<div class='field'>"
        "<label>Your Thoughts</label>"
        "<textarea name='content' placeholder='Write freely...' required></textarea>"
        "</div>"
        "<div style='display:flex;gap:1rem'>"
        "<button type='submit' class='btn btn-primary'>Save Entry &#128190;</button>"
        "<a href='/' class='btn btn-secondary'>Cancel</a>"
        "</div>"
        "</form>",
        alert, today);
    return wrap_page("New Entry", body);
}

/* Render all entries (optionally filtered) as HTML cards */
char *render_entries(DiaryEntry *entries, int count, const char *query) {
    /* We'll build into a large dynamic buffer */
    size_t cap = 256 + (size_t)count * 6000;
    char *buf = malloc(cap);
    if (!buf) return NULL;
    size_t pos = 0;

    if (query && *query) {
        char safe_query[512];
        html_escape(safe_query, query, sizeof(safe_query));
        pos += snprintf(buf+pos, cap-pos,
            "<div class='alert alert-info'>"
            "Showing results for <strong>\"%s\"</strong> — %d match%s found"
            "</div>",
            safe_query, count, count == 1 ? "" : "es");
    }

    if (count == 0) {
        pos += snprintf(buf+pos, cap-pos,
            "<div class='empty'>&#128196; No entries yet. "
            "<a href='/add'>Write your first entry!</a></div>");
    }

    for (int i = count - 1; i >= 0; i--) { /* newest first */
        char safe_title[512], safe_content[8192], safe_date[64], safe_id[64];
        html_escape(safe_title,   entries[i].title,   sizeof(safe_title));
        html_escape(safe_content, entries[i].content, sizeof(safe_content));
        html_escape(safe_date,    entries[i].date,    sizeof(safe_date));
        html_escape(safe_id,      entries[i].id,      sizeof(safe_id));

        pos += snprintf(buf+pos, cap-pos,
            "<div class='card'>"
            "<div class='card-date'>&#128197; %s</div>"
            "<div class='card-title'>%s</div>"
            "<div class='card-content'>%s</div>"
            "<div class='card-actions'>"
            "<a href='/delete?id=%s' class='btn btn-danger btn-sm' "
            "onclick=\"return confirm('Delete this entry?')\">&#128465; Delete</a>"
            "</div></div>",
            safe_date, safe_title, safe_content, safe_id);
    }
    return buf;
}

char *page_view(void) {
    DiaryEntry *entries = calloc(MAX_ENTRIES, sizeof(DiaryEntry));
    if (!entries) return wrap_page("All Entries", "<p>Error loading entries.</p>");
    int count = load_entries(entries, MAX_ENTRIES);

    char *cards = render_entries(entries, count, NULL);
    if (!cards) {
        free(entries);
        return wrap_page("All Entries", "<p>Error loading entries.</p>");
    }

    size_t cap = strlen(cards) + 256;
    char *body = malloc(cap);
    snprintf(body, cap,
        "<h1>&#128196; All Entries <span class='tag'>%d</span></h1>%s",
        count, cards);
    free(cards);
    free(entries);

    char *page = wrap_page("All Entries", body);
    free(body);
    return page;
}

char *page_search(const char *query) {
    char body_buf[65536];
    size_t pos = 0;
    char safe_query[512] = "";
    if (query) html_escape(safe_query, query, sizeof(safe_query));

    pos += snprintf(body_buf+pos, sizeof(body_buf)-pos,
        "<h1>&#128269; Search Entries</h1>"
        "<form method='GET' action='/search'>"
        "<div class='search-bar'>"
        "<input type='text' name='q' placeholder='Search by keyword or date...' "
        "value='%s' autofocus>"
        "<button type='submit' class='btn btn-primary'>Search</button>"
        "</div></form>",
        safe_query);

    if (query && *query) {
        DiaryEntry *all = calloc(MAX_ENTRIES, sizeof(DiaryEntry));
        DiaryEntry *matched = calloc(MAX_ENTRIES, sizeof(DiaryEntry));
        if (!all || !matched) {
            free(all);
            free(matched);
            return wrap_page("Search", body_buf);
        }

        int total = load_entries(all, MAX_ENTRIES);

        /* Filter entries that match the query (case-insensitive) */
        int mcount = 0;
        char lquery[256];
        strncpy(lquery, query, sizeof(lquery)-1);
        lquery[sizeof(lquery)-1] = '\0';
        for (size_t ci = 0; lquery[ci]; ci++) lquery[ci] = tolower(lquery[ci]);

        for (int i = 0; i < total; i++) {
            char tmp[sizeof(all[i].title) + sizeof(all[i].content) + sizeof(all[i].date)];
            snprintf(tmp, sizeof(tmp), "%s %s %s",
                     all[i].title, all[i].content, all[i].date);
            for (size_t ci = 0; tmp[ci]; ci++) tmp[ci] = tolower(tmp[ci]);
            if (strstr(tmp, lquery)) {
                matched[mcount++] = all[i];
            }
        }

        char *cards = render_entries(matched, mcount, query);
        if (cards) {
            snprintf(body_buf+pos, sizeof(body_buf)-pos, "%s", cards);
            free(cards);
        }
        free(all);
        free(matched);
    }

    return wrap_page("Search", body_buf);
}

/* ══════════════════════════════════════════════════════════
   HTTP LAYER
   ══════════════════════════════════════════════════════════ */

/* Send a full HTTP response */
void send_response(socket_t fd, int status, const char *status_text,
                   const char *content_type, const char *body) {
    char header[512];
    int body_len = body ? (int)strlen(body) : 0;
    int hlen = snprintf(header, sizeof(header),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: %s; charset=UTF-8\r\n"
        "Content-Length: %d\r\n"
        "Connection: close\r\n"
        "\r\n",
        status, status_text, content_type, body_len);
    send(fd, header, hlen, 0);
    if (body && body_len > 0) send(fd, body, body_len, 0);
}

/* Redirect helper */
void redirect(socket_t fd, const char *location) {
    char header[256];
    int hlen = snprintf(header, sizeof(header),
        "HTTP/1.1 302 Found\r\nLocation: %s\r\nConnection: close\r\n\r\n",
        location);
    send(fd, header, hlen, 0);
}

/* Parse the request line and extract method, path, query string */
void parse_request_line(const char *req,
                        char *method, size_t mlen,
                        char *path,   size_t plen,
                        char *query,  size_t qlen) {
    method[0] = path[0] = query[0] = '\0';
    sscanf(req, "%15s %1023s", method, path);
    /* Split path?query */
    char *q = strchr(path, '?');
    if (q) {
        strncpy(query, q+1, qlen-1);
        query[qlen-1] = '\0';
        *q = '\0';
    }
}

/* Find POST body (after blank line in request) */
const char *find_body(const char *req) {
    const char *p = strstr(req, "\r\n\r\n");
    return p ? p + 4 : NULL;
}

/* ── Route handlers ─────────────────────────────────────── */

void route_home(socket_t fd) {
    char *page = page_home();
    send_response(fd, 200, "OK", "text/html", page);
    free(page);
}

void route_add(socket_t fd, const char *query) {
    char msg[256] = "", errbuf[256] = "";
    char safe_msg[512] = "", safe_err[512] = "";
    get_field(query ? query : "", "msg",   msg,    sizeof(msg));
    get_field(query ? query : "", "error", errbuf, sizeof(errbuf));
    if (*msg) html_escape(safe_msg, msg, sizeof(safe_msg));
    if (*errbuf) html_escape(safe_err, errbuf, sizeof(safe_err));
    char *page = page_add(*safe_err ? safe_err : (*safe_msg ? safe_msg : NULL), *safe_err ? 1 : 0);
    send_response(fd, 200, "OK", "text/html", page);
    free(page);
}

void route_save(socket_t fd, const char *body) {
    if (!body) { redirect(fd, "/add?error=No+data+received"); return; }

    DiaryEntry e;
    memset(&e, 0, sizeof(e));

    get_field(body, "date",    e.date,    sizeof(e.date));
    get_field(body, "title",   e.title,   sizeof(e.title));
    get_field(body, "content", e.content, sizeof(e.content));

    if (!*e.date || !*e.title || !*e.content) {
        redirect(fd, "/add?error=All+fields+are+required");
        return;
    }

    gen_id(e.id);

    if (!save_entry(&e)) {
        redirect(fd, "/add?error=Failed+to+save+entry");
        return;
    }
    redirect(fd, "/add?msg=Entry+saved+successfully!");
}

void route_view(socket_t fd) {
    char *page = page_view();
    send_response(fd, 200, "OK", "text/html", page);
    free(page);
}

void route_search(socket_t fd, const char *query) {
    char q[256] = "";
    if (query) get_field(query, "q", q, sizeof(q));
    char *page = page_search(*q ? q : NULL);
    send_response(fd, 200, "OK", "text/html", page);
    free(page);
}

void route_delete(socket_t fd, const char *query) {
    char id[64] = "";
    if (query) get_field(query, "id", id, sizeof(id));
    if (*id) delete_entry(id);
    redirect(fd, "/view");
}

void route_not_found(socket_t fd) {
    const char *body =
        "<!DOCTYPE html><html><body style='font-family:serif;text-align:center;padding:4rem'>"
        "<h1 style='font-size:5rem;color:#c0392b'>404</h1>"
        "<p>Page not found. <a href='/'>Go home</a></p>"
        "</body></html>";
    send_response(fd, 404, "Not Found", "text/html", body);
}

/* ── Main request dispatcher ────────────────────────────── */
void handle_request(socket_t client_fd) {
    char buf[BUF_SIZE];
    int n = recv(client_fd, buf, sizeof(buf)-1, 0);
    if (n <= 0) return;
    buf[n] = '\0';

    char method[16], path[1024], query[1024];
    parse_request_line(buf, method, sizeof(method),
                            path,   sizeof(path),
                            query,  sizeof(query));

    printf("[%s] %s%s%s\n", method, path,
           *query ? "?" : "", *query ? query : "");

    const char *body = find_body(buf);

    /* Route table */
    if (strcmp(path, "/") == 0) {
        route_home(client_fd);
    } else if (strcmp(path, "/add") == 0) {
        route_add(client_fd, query);
    } else if (strcmp(path, "/save") == 0 && strcmp(method, "POST") == 0) {
        route_save(client_fd, body);
    } else if (strcmp(path, "/view") == 0) {
        route_view(client_fd);
    } else if (strcmp(path, "/search") == 0) {
        route_search(client_fd, *query ? query : NULL);
    } else if (strcmp(path, "/delete") == 0) {
        route_delete(client_fd, query);
    } else {
        route_not_found(client_fd);
    }
}

/* ══════════════════════════════════════════════════════════
   MAIN — TCP server loop
   ══════════════════════════════════════════════════════════ */
int main(void) {
#ifdef _WIN32
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        fprintf(stderr, "WSAStartup failed\n");
        return 1;
    }
#endif

    /* Ensure data directory exists */
    MKDIR("data");

    /* Create TCP socket */
    socket_t server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == INVALID_SOCKET) {
        perror("socket");
#ifdef _WIN32
        WSACleanup();
#endif
        return 1;
    }

    /* Allow port reuse (avoids "address in use" on restart) */
    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, (const char *)&opt, sizeof(opt));

    /* Bind to all interfaces on PORT */
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family      = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port        = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        CLOSE_SOCKET(server_fd);
#ifdef _WIN32
        WSACleanup();
#endif
        return 1;
    }

    if (listen(server_fd, BACKLOG) < 0) {
        perror("listen");
        CLOSE_SOCKET(server_fd);
#ifdef _WIN32
        WSACleanup();
#endif
        return 1;
    }

    printf("╔══════════════════════════════════════╗\n");
    printf("║    MyDiary Server is running!        ║\n");
    printf("║    http://localhost:%d              ║\n", PORT);
    printf("║    Press Ctrl+C to stop              ║\n");
    printf("╚══════════════════════════════════════╝\n");

    /* Sequential request loop */
    while (1) {
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);

        socket_t client_fd = accept(server_fd,
                                    (struct sockaddr *)&client_addr,
                                    &client_len);
        if (client_fd == INVALID_SOCKET) { perror("accept"); continue; }

        handle_request(client_fd);
        CLOSE_SOCKET(client_fd);
    }

    CLOSE_SOCKET(server_fd);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
