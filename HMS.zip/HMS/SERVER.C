/*
 * Hostel Management System HTTP server
 * Routes:
 *   GET  /
 *   GET  /view
 *   POST /add
 *   POST /delete
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#ifdef _MSC_VER
#pragma comment(lib, "ws2_32.lib")
#endif
typedef SOCKET socket_t;
#define socket_close closesocket
#define socket_read(fd, buf, len) recv((fd), (buf), (int)(len), 0)
#define socket_write(fd, buf, len) send((fd), (buf), (int)(len), 0)
#define strcasecmp _stricmp
#else
#include <unistd.h>
#include <strings.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
typedef int socket_t;
#define INVALID_SOCKET (-1)
#define SOCKET_ERROR   (-1)
#define socket_close close
#define socket_read read
#define socket_write write
#endif

#define PORT            8080
#define BUFFER_SIZE     65536
#define RESPONSE_SIZE   65536
#define MAX_STUDENTS    200
#define DATA_FILE       "students.txt"
#define MAX_NAME        64
#define MAX_ROOM        16
#define MAX_CONTACT     20

typedef struct {
    int id;
    char name[MAX_NAME];
    char room[MAX_ROOM];
    char contact[MAX_CONTACT];
} Student;

typedef struct {
    char data[BUFFER_SIZE];
    int total_bytes;
    char *body;
    int body_length;
} HttpRequest;

static Student students[MAX_STUDENTS];
static int student_count = 0;
static int next_id = 1;

void copy_text(char *dest, const char *src, int dest_size) {
    if (dest_size <= 0) {
        return;
    }
    strncpy(dest, src, dest_size - 1);
    dest[dest_size - 1] = '\0';
}

void save_to_file(void) {
    FILE *fp = fopen(DATA_FILE, "w");
    int i;

    if (fp == NULL) {
        fprintf(stderr, "[ERROR] Could not open %s for writing\n", DATA_FILE);
        return;
    }

    for (i = 0; i < student_count; i++) {
        fprintf(fp, "%d|%s|%s|%s\n",
                students[i].id,
                students[i].name,
                students[i].room,
                students[i].contact);
    }

    fclose(fp);
}

void load_from_file(void) {
    FILE *fp = fopen(DATA_FILE, "r");
    char line[256];

    if (fp == NULL) {
        printf("[FILE] %s not found, starting with empty data.\n", DATA_FILE);
        return;
    }

    student_count = 0;
    next_id = 1;

    while (fgets(line, sizeof(line), fp) != NULL && student_count < MAX_STUDENTS) {
        Student *s = &students[student_count];
        char *token = strtok(line, "|");

        if (token == NULL) {
            continue;
        }
        s->id = atoi(token);

        token = strtok(NULL, "|");
        if (token == NULL) {
            continue;
        }
        copy_text(s->name, token, MAX_NAME);

        token = strtok(NULL, "|");
        if (token == NULL) {
            continue;
        }
        copy_text(s->room, token, MAX_ROOM);

        token = strtok(NULL, "\r\n");
        if (token == NULL) {
            continue;
        }
        copy_text(s->contact, token, MAX_CONTACT);

        if (s->id >= next_id) {
            next_id = s->id + 1;
        }

        student_count++;
    }

    fclose(fp);
}

void send_response(socket_t client_fd, const char *status, const char *body) {
    char response[RESPONSE_SIZE];
    int body_len = (int)strlen(body);
    const char *content_type = body_len > 0 ? "application/json" : "text/plain";

    snprintf(
        response,
        sizeof(response),
        "HTTP/1.1 %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %d\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
        "Access-Control-Allow-Headers: Content-Type\r\n"
        "Access-Control-Max-Age: 86400\r\n"
        "Connection: close\r\n"
        "\r\n"
        "%s",
        status,
        content_type,
        body_len,
        body
    );

    socket_write(client_fd, response, (int)strlen(response));
}

char *get_request_body(char *request) {
    char *body = strstr(request, "\r\n\r\n");
    if (body == NULL) {
        return NULL;
    }
    return body + 4;
}

int get_content_length(const char *request) {
    const char *header = strstr(request, "Content-Length:");

    if (header == NULL) {
        return 0;
    }

    header += (int)strlen("Content-Length:");
    while (*header == ' ' || *header == '\t') {
        header++;
    }

    return atoi(header);
}

int read_http_request(socket_t client_fd, HttpRequest *request) {
    int expected_total = 0;

    memset(request, 0, sizeof(*request));

    while (request->total_bytes < (int)sizeof(request->data) - 1) {
        int bytes_read = socket_read(
            client_fd,
            request->data + request->total_bytes,
            sizeof(request->data) - 1 - request->total_bytes
        );
        if (bytes_read <= 0) {
            break;
        }

        request->total_bytes += bytes_read;
        request->data[request->total_bytes] = '\0';

        if (expected_total == 0) {
            char *body = get_request_body(request->data);
            if (body != NULL) {
                int header_bytes = (int)(body - request->data);
                int content_length = get_content_length(request->data);
                expected_total = header_bytes + content_length;

                if (content_length == 0 || request->total_bytes >= expected_total) {
                    break;
                }
            }
        } else if (request->total_bytes >= expected_total) {
            break;
        }
    }

    request->body = get_request_body(request->data);
    if (request->body != NULL) {
        request->body_length = request->total_bytes - (int)(request->body - request->data);
    }

    return request->total_bytes;
}

int extract_json_field(const char *json, const char *field, char *out, int out_size) {
    char search[64];
    const char *pos;
    int i = 0;

    snprintf(search, sizeof(search), "\"%s\":", field);
    pos = strstr(json, search);
    if (pos == NULL) {
        return 0;
    }

    pos += strlen(search);
    while (*pos == ' ' || *pos == '\t') {
        pos++;
    }

    if (*pos == '"') {
        pos++;
        while (*pos != '\0' && *pos != '"' && i < out_size - 1) {
            out[i++] = *pos++;
        }
    } else {
        while (*pos != '\0' &&
               *pos != ',' &&
               *pos != '}' &&
               *pos != ' ' &&
               *pos != '\t' &&
               *pos != '\r' &&
               *pos != '\n' &&
               i < out_size - 1) {
            out[i++] = *pos++;
        }
    }

    out[i] = '\0';
    return i > 0;
}

void handle_view(socket_t client_fd) {
    char body[RESPONSE_SIZE];
    int offset = 0;
    int i;

    offset += snprintf(
        body + offset,
        sizeof(body) - offset,
        "{\"success\":true,\"count\":%d,\"students\":[",
        student_count
    );

    for (i = 0; i < student_count && offset < (int)sizeof(body); i++) {
        offset += snprintf(
            body + offset,
            sizeof(body) - offset,
            "%s{\"id\":%d,\"name\":\"%s\",\"room\":\"%s\",\"contact\":\"%s\"}",
            (i > 0) ? "," : "",
            students[i].id,
            students[i].name,
            students[i].room,
            students[i].contact
        );
    }

    snprintf(body + offset, sizeof(body) - offset, "]}");
    send_response(client_fd, "200 OK", body);
}

void handle_add(socket_t client_fd, HttpRequest *request) {
    char name[MAX_NAME] = {0};
    char room[MAX_ROOM] = {0};
    char contact[MAX_CONTACT] = {0};
    char response[256];
    int i;
    Student *s;

    if (request->body == NULL || request->body_length < 3) {
        send_response(client_fd, "400 Bad Request",
                      "{\"success\":false,\"message\":\"Request body missing\"}");
        return;
    }

    if (!extract_json_field(request->body, "name", name, sizeof(name)) ||
        !extract_json_field(request->body, "room", room, sizeof(room)) ||
        !extract_json_field(request->body, "contact", contact, sizeof(contact))) {
        send_response(client_fd, "400 Bad Request",
                      "{\"success\":false,\"message\":\"name, room, contact fields required\"}");
        return;
    }

    for (i = 0; i < student_count; i++) {
        if (strcasecmp(students[i].room, room) == 0) {
            snprintf(
                response,
                sizeof(response),
                "{\"success\":false,\"message\":\"Room %s already occupied by %s\"}",
                room,
                students[i].name
            );
            send_response(client_fd, "409 Conflict", response);
            return;
        }
    }

    if (student_count >= MAX_STUDENTS) {
        send_response(client_fd, "507 Insufficient Storage",
                      "{\"success\":false,\"message\":\"Hostel full\"}");
        return;
    }

    s = &students[student_count];
    s->id = next_id++;
    copy_text(s->name, name, MAX_NAME);
    copy_text(s->room, room, MAX_ROOM);
    copy_text(s->contact, contact, MAX_CONTACT);
    student_count++;
    save_to_file();

    snprintf(
        response,
        sizeof(response),
        "{\"success\":true,\"message\":\"Student added successfully\",\"id\":%d}",
        s->id
    );
    send_response(client_fd, "201 Created", response);
}

void handle_delete(socket_t client_fd, HttpRequest *request) {
    char id_str[16] = {0};
    char deleted_name[MAX_NAME];
    char response[256];
    int target_id;
    int found_index = -1;
    int i;

    if (request->body == NULL || request->body_length <= 0) {
        send_response(client_fd, "400 Bad Request",
                      "{\"success\":false,\"message\":\"Request body missing\"}");
        return;
    }

    if (!extract_json_field(request->body, "id", id_str, sizeof(id_str))) {
        send_response(client_fd, "400 Bad Request",
                      "{\"success\":false,\"message\":\"\\\"id\\\" field required\"}");
        return;
    }

    target_id = atoi(id_str);

    for (i = 0; i < student_count; i++) {
        if (students[i].id == target_id) {
            found_index = i;
            break;
        }
    }

    if (found_index == -1) {
        snprintf(
            response,
            sizeof(response),
            "{\"success\":false,\"message\":\"Student with id %d not found\"}",
            target_id
        );
        send_response(client_fd, "404 Not Found", response);
        return;
    }

    copy_text(deleted_name, students[found_index].name, MAX_NAME);

    for (i = found_index; i < student_count - 1; i++) {
        students[i] = students[i + 1];
    }

    student_count--;
    save_to_file();

    snprintf(
        response,
        sizeof(response),
        "{\"success\":true,\"message\":\"Student '%s' removed successfully\"}",
        deleted_name
    );
    send_response(client_fd, "200 OK", response);
}

void handle_welcome(socket_t client_fd) {
    const char *body =
        "{"
        "\"message\":\"Welcome to Hostel Management System (C Server)\","
        "\"version\":\"1.1\","
        "\"routes\":{"
        "\"GET /view\":\"View all students\","
        "\"POST /add\":\"Add student - body: {name, room, contact}\","
        "\"POST /delete\":\"Delete student - body: {id}\""
        "}"
        "}";

    send_response(client_fd, "200 OK", body);
}

void route_request(socket_t client_fd, HttpRequest *request) {
    printf("[REQUEST] %.80s\n", request->data);

    if (strncmp(request->data, "GET /view ", 10) == 0) {
        handle_view(client_fd);
    } else if (strncmp(request->data, "GET / ", 6) == 0 ||
               strncmp(request->data, "GET /HTTP", 9) == 0) {
        handle_welcome(client_fd);
    } else if (strncmp(request->data, "POST /add ", 10) == 0) {
        handle_add(client_fd, request);
    } else if (strncmp(request->data, "POST /delete ", 13) == 0) {
        handle_delete(client_fd, request);
    } else if (strncmp(request->data, "OPTIONS ", 8) == 0) {
        send_response(client_fd, "204 No Content", "");
    } else {
        send_response(client_fd, "404 Not Found",
                      "{\"success\":false,\"message\":\"Route not found. Try GET /view, POST /add, POST /delete\"}");
    }
}

int main(void) {
    socket_t server_fd;
    struct sockaddr_in address;
    int opt = 1;

#ifdef _WIN32
    WSADATA wsa_data;
    if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0) {
        fprintf(stderr, "[ERROR] WSAStartup failed\n");
        return EXIT_FAILURE;
    }
#endif

    load_from_file();

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == INVALID_SOCKET) {
        perror("[ERROR] Socket creation failed");
#ifdef _WIN32
        WSACleanup();
#endif
        return EXIT_FAILURE;
    }

    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, (const char *)&opt, sizeof(opt));

    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("[ERROR] Bind failed");
        socket_close(server_fd);
#ifdef _WIN32
        WSACleanup();
#endif
        return EXIT_FAILURE;
    }

    if (listen(server_fd, 10) < 0) {
        perror("[ERROR] Listen failed");
        socket_close(server_fd);
#ifdef _WIN32
        WSACleanup();
#endif
        return EXIT_FAILURE;
    }

    printf("Server running on http://localhost:%d\n", PORT);
    printf("GET  /view\n");
    printf("POST /add\n");
    printf("POST /delete\n");

    while (1) {
        struct sockaddr_in client_addr;
        HttpRequest request;
        socket_t client_fd;
        int bytes_read;

#ifdef _WIN32
        int client_len = sizeof(client_addr);
#else
        socklen_t client_len = sizeof(client_addr);
#endif

        client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &client_len);
        if (client_fd == INVALID_SOCKET) {
            perror("[WARN] Accept failed");
            continue;
        }

        printf("[CONN] Client connected: %s\n", inet_ntoa(client_addr.sin_addr));

        bytes_read = read_http_request(client_fd, &request);
        if (bytes_read > 0) {
            route_request(client_fd, &request);
        }

        socket_close(client_fd);
    }

    socket_close(server_fd);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
